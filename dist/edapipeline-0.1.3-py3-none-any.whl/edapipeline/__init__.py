#  EDAPipeline - Comprehensive EDA toolkit for data analysis.

from .core import EDAPipeline
from .__version__ import __version__

__all__ = ['EDAPipeline']