# setup.py
# IMPORTANT: Save this file with UTF-8 Encoding!

from setuptools import setup
import sys
import os
import time
import math

# --- Setup Call ---
# This line is crucial. It tells setuptools to proceed using setup.cfg for config.
setup()
